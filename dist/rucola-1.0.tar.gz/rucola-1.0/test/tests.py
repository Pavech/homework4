TEST_CASES = [
    {"test_input": "https:ya.ru", "expected": True},
    {"test_input": "https:yayaya.ru/fake_page", "expected": False},
]
