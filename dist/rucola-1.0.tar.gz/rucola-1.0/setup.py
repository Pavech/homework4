from distutils.core import setup
setup(name='rucola',
      version='1.0',
      py_modules=['rucola'],
      )